# Ideas
openCoLab Idea - Sand Crab Tracker

The problem: How do you know when a sand crab is drunk?
The answer: He walks in a straight line.

That's where the Sand Crab Tracker comes in. By monitoring a sand crab's movements by wee GPS trackers hidden in barnacles, it is possible to record position data and then analyse it to see if the crab is walking in a straight line for 3 consecutive body lengths.

Sand crabs are sneaky. That's why we need to hide the GPS tracker.
